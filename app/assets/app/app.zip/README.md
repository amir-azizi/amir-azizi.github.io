# A counter_flet_app Flet app

An example of a counter Flet app.

To run the app:

```
flet run [app_directory]
```